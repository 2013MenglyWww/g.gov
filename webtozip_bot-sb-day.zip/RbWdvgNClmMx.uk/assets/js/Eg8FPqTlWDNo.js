var isRtl = $('html').attr('data-textdirection') === 'rtl';
function showSuccessToastr(message) {
    if (message) {
        toastr['success'](message, 'Success', {
            closeButton: true,
            tapToDismiss: true,
            timeOut : 1000,
            progressBar: true,
            positionClass: 'toast-bottom-left',
            rtl: isRtl
        });
    }
}
function showErrorToastr(errMessage) {
    if (errMessage) {
        toastr['error'](errMessage, 'Error', {
            closeButton: true,
            tapToDismiss: false,
            timeOut : 1000,
            positionClass: 'toast-bottom-left',
            progressBar: true,
            rtl: isRtl
        });
    }

}
